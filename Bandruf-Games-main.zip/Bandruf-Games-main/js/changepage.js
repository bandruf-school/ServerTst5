function change_page(){
    window.location.href = "pages/games.html"
}